﻿namespace T9___AD_1232923
{
    public class Motocicleta
    {

        private int modelo = 2019;
        private double precio = 1000;
        private string m;
        private double IVA = 0.12;
       

        public int Modelo { get => modelo; set => modelo = value;}
        public double Precio { get => precio; set => precio = value;}
        public string M { get => m; set => m = value; }
        public double IVA1 { get => IVA; set => IVA = value; }

        public void Crearmoto(int _modelo, double _precio, string _m, double _IVA)
        {
          modelo = _modelo;
          precio = _precio;
          m=  _m;   
          IVA = _IVA;

        }



    }



}
