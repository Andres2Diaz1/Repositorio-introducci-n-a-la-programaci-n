﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9___AD_1232923
{
    class persona
    {
        static void Main(string[] args)
        {
            Motocicleta objMotocicleta = new Motocicleta();

            //Ingrese loa datos necesarios en esta seccion//
            objMotocicleta.Crearmoto(2019, 1000, " toyota ", 0.12);

            Console.WriteLine("modelo: " + objMotocicleta.Modelo);
            Console.WriteLine("precio: " + objMotocicleta.Precio);
            Console.WriteLine("marca: " + objMotocicleta.M);
            Console.WriteLine("IVA: " + objMotocicleta.IVA1);

            objMotocicleta.Precio= objMotocicleta.Precio - (objMotocicleta.Precio * objMotocicleta.IVA1);
            Console.WriteLine("El precio con IVa es de: " + objMotocicleta.Precio);
            


            Console.ReadLine();
        }      
    }
}
