﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace Actividad_practica_15
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Ingrese el valor de  su cateto A");

            double a;
            a = Convert.ToDouble(Console.ReadLine());


            Console.WriteLine("Ingrese el valor de su angulo opuesto al cateto A");
            double b; b = Convert.ToDouble(Console.ReadLine());

            new trianguloRectangulo(a, b);

            Console.WriteLine("El valor de el cateto A es de: " + ),


            Console.ReadKey();

         
        }
    }
}
