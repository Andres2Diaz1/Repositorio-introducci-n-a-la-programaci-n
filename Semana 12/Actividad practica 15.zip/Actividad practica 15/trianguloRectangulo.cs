﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_practica_15
{
    internal class trianguloRectangulo
    {
        private double catetoA;
        private double AnguloOpuestoA;
   

        public trianguloRectangulo(double catetoAdy, double Angulo)
        {
            this.catetoA = catetoAdy;
            this.AnguloOpuestoA= Angulo;
        }

        public double ObtenerCatetoB(double catetoB)
        {

            if (AnguloOpuestoA> 180)
            {
                catetoB = catetoA * Math.Tan(AnguloOpuestoA);
            }
            else 
            {
                Console.WriteLine("El valor del angulo no debe superar los 180 grados");
            }    

            return catetoB;
        }

        public double ObtenerHipotenusa(double Hipotenusa, double catetoB)
        {
            Hipotenusa = Math.Pow((Math.Pow(catetoA, 2) + Math.Pow(catetoB, 2)), 0.5);
            return Hipotenusa;
        }

        public double ObtenerArea(double Area, double catetoB) 
        {
            Area = (catetoA * catetoB) / 2;
           return Area;
        }

        public double ObtnerAbguloOpuestoB(double AnguloB)
        {
            AnguloB = 180 - AnguloOpuestoA - 90;
            return AnguloB;
        }

    }
}
