﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1___iniciales_carné
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo ");
            Console.WriteLine("soy NOMBRE");

            /* El comando Write permite usar una sola linea mientras que con 
             * el comando WriteLine hace que en cada WrtiteLine que se use el texto se separara en lineas diferentes */

            Console.Write("Hola Mundo");
            Console.Write("soy NOMBRE");
            Console.ReadKey();

        }
    }
}
