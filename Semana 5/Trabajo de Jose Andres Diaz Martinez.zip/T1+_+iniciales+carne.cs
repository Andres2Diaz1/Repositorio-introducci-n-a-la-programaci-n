﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");

            Console.WriteLine("Nombre");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Edad");
            string Edad = Console.ReadLine();

            Console.WriteLine("Carrera");
            String Carrera = Console.ReadLine();

            Console.WriteLine("Carne");
            String Carne = Console.ReadLine();

            Console.WriteLine(" soy " + Nombre + " tengo " + Edad + " años y estudio la carrera de " + Carrera + " Mi numero de carne es; " + Carne);  
            Console.ReadKey();
        }
    }
}
