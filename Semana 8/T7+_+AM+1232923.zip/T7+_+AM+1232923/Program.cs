﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T7___AM_1232923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un numero para la variable x");
            double x; x = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese un numero para la variable a");
            double a; a = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese un numero para la variable n");
            double n; n = Convert.ToDouble(Console.ReadLine());
            double k = 0;


            if (a > 0 && x > 0 && n > 0) 
            {

                a = (1 / 1) + (1 / 2) + (1 / 3) +(1 / n);

                x = (1 / 2 ^ 1) + (1 / 2 ^ 2) + (1 / 2 ^ 3) + (1 / Math.Pow(2, n));

                n = Math.Pow(x,k)*Math.Pow(a, n - k);

               
            }
            else
            {
                Console.WriteLine("Valores invalidos");
            }


            Console.WriteLine("El valor para la primera operación es de: " + a);
            Console.WriteLine("El valor para la segunda operación es de: " + x);
            Console.WriteLine("El valor para la segunda operación es de: " + n);

            Console.ReadKey();
        }
    }
}
